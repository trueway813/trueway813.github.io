---
layout: page
title: About
permalink: /about/
---

Hi，我是 lemon.

### 技能

Linux后端分布式高性能服务开发，差一点精通 C++，Golang 成长中，Python小玩具。

### 经历

软件工程师(Software Engineer)，电子信息工程学士学位( Electronic and Information Engineering )，从事服务器软件后台开发工作多年，现就职腾讯（Tencent）公司。

个人技术公众号「后端技术学堂」分享、记录、成长，欢迎扫码添加。

![公众号二维码](https://upload-images.jianshu.io/upload_images/7842464-15f939ec039690f6.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)



### 版权声明

博客文章是我原创文章，存档于_posts 文件夹下，版权归我所有，转载请与我联系获得授权许可。

